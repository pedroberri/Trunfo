package br.senai.sc.trunfoapi.model.enums;

public enum Posicao {
    ADD, LD, ZAG, LE, ADE, VOL, MD, MC, ME, MEI, SA, PD, ATA, PE
}
